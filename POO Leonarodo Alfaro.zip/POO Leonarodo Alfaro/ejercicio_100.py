class menuoperaciones:
    def factorial(self, n):
        resultado = 1
        for numero in range(2, n + 1):
            resultado *= numero
        return resultado

    def ejecutar(self):
        while True:
            print("\n=== MENU DE OPERACIONES ===")
            print("1. factorial\n2. tabla de multiplicar\n3. verificar paridad")
            print("4. calcular cuadrado\n5. salir")
            opcion = input("seleccione una opcion: ").strip()
            if opcion == "5":
                print("programa finalizado.")
                break
            if opcion not in {"1", "2", "3", "4"}:
                print("opción no valida.")
                continue
            try:
                numero = int(input("ingrese un número entero: "))
            except ValueError:
                print("debe ingresar un entero.")
                continue
            if opcion == "1":
                if numero < 0:
                    print("el factorial no está definido para enteros negativos.")
                else:
                    print(f"{numero}! = {self.factorial(numero)}")
            elif opcion == "2":
                for i in range(1, 13):
                    print(f"{numero} x {i:2} = {numero * i}")
            elif opcion == "3":
                print(f"{numero} es {'par' if numero % 2 == 0 else 'impar'}.")
            elif opcion == "4":
                print(f"cuadrado de {numero}: {numero ** 2}")

if __name__ == "__main__":
    menuoperaciones().ejecutar()
