class contadorparidad:
    def ejecutar(self):
        pares = impares = 0
        for i in range(1, 11):
            while True:
                try:
                    numero = int(input(f"ingrese el numero {i}/10: "))
                    break
                except ValueError:
                    print("Entrada invalida. ingrese un numero entero.")
            if numero % 2 == 0:
                pares += 1
            else:
                impares += 1
        print(f"\ncantidad de pares: {pares}")
        print(f"cantidad de impares: {impares}")

if __name__ == "__main__":
    ContadorParidad().ejecutar()
    