class mayormenor:
    def ejecutar(self):
        mayor = menor = None
        for i in range(1, 11):
            while True:
                try:
                    numero = float(input(f"ingrese el numero {i}/10: "))
                    break
                except ValueError:
                    print("entrada invalida. ingrese un numero.")
            if mayor is None or numero > mayor:
                mayor = numero
            if menor is None or numero < menor:
                menor = numero
        print(f"\nmayor: {mayor:g}")
        print(f"menor: {menor:g}")

if __name__ == "__main__":
    mayormenor().ejecutar()
