class sumapromedio:
    def ejecutar(self):
        while True:
            try:
                n = int(input("¿cuantos numeros ingresara? "))
                if n > 0:
                    break
                print("N debe ser mayor que cero.")
            except ValueError:
                print("ingrese un entero valido.")
        suma = 0.0
        for i in range(1, n + 1):
            while True:
                try:
                    suma += float(input(f"numero {i}/{n}: "))
                    break
                except ValueError:
                    print("ingrese un numero valido.")
        print(f"\nsuma: {suma:g}")
        print(f"promedio: {suma / n:g}")

if __name__ == "__main__":
    sumapromedio().ejecutar()
