class clasificadornumeros:
    def ejecutar(self):
        while True:
            try:
                n = int(input("¿cuantos numeros ingresara? "))
                if n > 0:
                    break
                print("N debe ser mayor que cero.")
            except ValueError:
                print("ingrese un entero valido.")
        positivos = negativos = ceros = 0
        for i in range(1, n + 1):
            while True:
                try:
                    numero = float(input(f"numero {i}/{n}: "))
                    break
                except ValueError:
                    print("ingrese un numero valido.")
            if numero > 0:
                positivos += 1
            elif numero < 0:
                negativos += 1
            else:
                ceros += 1
        print(f"\npositivos: {positivos}")
        print(f"negativos: {negativos}")
        print(f"ceros: {ceros}")

if __name__ == "__main__":
    clasificadornumeros().ejecutar()
