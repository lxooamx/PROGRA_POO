class tablamultiplicar:
    def mostrar_tabla(self, numero):
        print(f"\ntabla del {numero}")
        for multiplicador in range(1, 13):
            print(f"{numero} x {multiplicador:2} = {numero * multiplicador}")

    def ejecutar(self):
        while True:
            try:
                numero = int(input("ingrese un numero para ver su tabla: "))
                self.mostrar_tabla(numero)
            except ValueError:
                print("ingrese un numero entero valido.")
                continue
            opcion = input("\n¿desea mostrar otra tabla? (s/n): ").strip().lower()
            if opcion != "s":
                print("programa finalizado.")
                break

if __name__ == "__main__":
    tablamultiplicar().ejecutar()
