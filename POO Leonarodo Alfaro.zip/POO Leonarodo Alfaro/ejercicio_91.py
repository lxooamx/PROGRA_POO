class calculadora:
    def ejecutar(self):
        while True:
            print("\n=== CALCULADORA ===")
            print("1. Sumar\n2. Restar\n3. Multiplicar\n4. Dividir\n5. Salir")
            opcion = input("Seleccione una opción: ").strip()
            if opcion == "5":
                print("Hasta luego.")
                break
            if opcion not in {"1", "2", "3", "4"}:
                print("Opción no válida.")
                continue
            try:
                a = float(input("Primer número: "))
                b = float(input("Segundo número: "))
            except ValueError:
                print("debe ingresar numeros validos.")
                continue
            if opcion == "1":
                resultado = a + b
            elif opcion == "2":
                resultado = a - b
            elif opcion == "3":
                resultado = a * b
            else:
                if b == 0:
                    print("error: no se puede dividir entre cero.")
                    continue
                resultado = a / b
            print(f"resultado: {resultado:g}")

if __name__ == "__main__":
    calculadora().ejecutar()
