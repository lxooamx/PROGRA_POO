import math

class areasgeometricas:
    def pedir_positivo(self, mensaje):
        while True:
            try:
                valor = float(input(mensaje))
                if valor > 0:
                    return valor
                print("el valor debe ser mayor que cero.")
            except ValueError:
                print("ingrese un número valido.")

    def ejecutar(self):
        while True:
            print("\n=== areas geometricas ===")
            print("1. cuadrado\n2. rectangulo\n3. Triangulo\n4. círculo\n5. salir")
            opcion = input("seleccione una figura: ").strip()
            if opcion == "5":
                break
            if opcion == "1":
                lado = self.pedir_positivo("lado: ")
                area = lado ** 2
            elif opcion == "2":
                base = self.pedir_positivo("base: ")
                altura = self.pedir_positivo("altura: ")
                area = base * altura
            elif opcion == "3":
                base = self.pedir_positivo("base: ")
                altura = self.pedir_positivo("altura: ")
                area = base * altura / 2
            elif opcion == "4":
                radio = self.pedir_positivo("radio: ")
                area = math.pi * radio ** 2
            else:
                print("opcion no valida.")
                continue
            print(f"area: {area:.2f}")
        print("programa finalizado.")

if __name__ == "__main__":
    areasgeometricas().ejecutar()
