class registronotas:
    def ejecutar(self):
        notas = []
        print("ingrese notas entre 0 y 100. escriba 'fin' para terminar.")
        while True:
            entrada = input("nota: ").strip().lower()
            if entrada == "fin":
                break
            try:
                nota = float(entrada)
                if not 0 <= nota <= 100:
                    print("la nota debe estar entre 0 y 100.")
                    continue
                notas.append(nota)
            except ValueError:
                print("ingrese una nota valida o 'fin'.")
        if not notas:
            print("no se ingresaron notas.")
            return
        print(f"cantidad: {len(notas)}")
        print(f"promedio: {sum(notas) / len(notas):.2f}")
        print(f"nota mayor: {max(notas):g}")
        print(f"nota menor: {min(notas):g}")

if __name__ == "__main__":
    registronotas().ejecutar()
