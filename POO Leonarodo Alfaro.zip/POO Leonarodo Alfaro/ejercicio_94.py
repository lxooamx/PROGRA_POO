class registroedades:
    def ejecutar(self):
        mayores = menores = total = 0
        print("ingrese edades. ingrese 0 para terminar.")
        while True:
            try:
                edad = int(input("edad: "))
            except ValueError:
                print("ingrese una edad entera.")
                continue
            if edad == 0:
                break
            if edad < 0:
                print("la edad no puede ser negativa.")
                continue
            total += 1
            if edad >= 18:
                mayores += 1
            else:
                menores += 1
        print(f"\nedades registradas: {total}")
        print(f"mayores de edad (18 o más): {mayores}")
        print(f"menores de edad: {menores}")

if __name__ == "__main__":
    registroedades().ejecutar()
