class estadisticanumeros:
    def ejecutar(self):
        pares = impares = positivos = negativos = 0
        print("ingrese numeros enteros. ingrese 0 para terminar.")
        while True:
            try:
                numero = int(input("Numero: "))
            except ValueError:
                print("ingrese un numero entero.")
                continue
            if numero == 0:
                break
            if numero % 2 == 0:
                pares += 1
            else:
                impares += 1
            if numero > 0:
                positivos += 1
            else:
                negativos += 1
        print(f"\nPares: {pares}")
        print(f"impares: {impares}")
        print(f"positivos: {positivos}")
        print(f"negativos: {negativos}")

if __name__ == "__main__":
    estadisticanumeros().ejecutar()
