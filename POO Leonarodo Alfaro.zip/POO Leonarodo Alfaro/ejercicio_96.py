class carritocompras:
    def ejecutar(self):
        total = 0.0
        productos = []
        while True:
            print("\n=== REGISTRO DE PRODUCTOS ===")
            print("1. agregar producto\n2. finalizar compra")
            opcion = input("opcion: ").strip()
            if opcion == "2":
                break
            if opcion != "1":
                print("opcion no valida.")
                continue
            nombre = input("nombre del producto: ").strip()
            if not nombre:
                print("el nombre no puede estar vacio.")
                continue
            try:
                precio = float(input("precio: "))
                if precio < 0:
                    print("el precio no puede ser negativo.")
                    continue
            except ValueError:
                print("ingrese un precio valido.")
                continue
            productos.append((nombre, precio))
            total += precio
            print(f"agregado: {nombre} — {precio:.2f}")
        print("\n=== RESUMEN ===")
        if not productos:
            print("no se registraron productos.")
        for nombre, precio in productos:
            print(f"{nombre}: {precio:.2f}")
        print(f"TOTAL: {total:.2f}")

if __name__ == "__main__":
     carritocompras().ejecutar()
