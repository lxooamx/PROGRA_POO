class cuentabancaria:
    def __init__(self, saldo_inicial=0.0):
        self.saldo = saldo_inicial

    def ejecutar(self):
        while True:
            print("\n=== MENÚ BANCARIO ===")
            print("1. consultar saldo\n2. depositar\n3. retirar\n4. salir")
            opcion = input("seleccione una opcion: ").strip()
            if opcion == "1":
                print(f"saldo actual: Bs {self.saldo:.2f}")
            elif opcion == "2":
                try:
                    monto = float(input("monto a depositar (Bs): "))
                    if monto <= 0:
                        print("el monto debe ser mayor que cero.")
                    else:
                        self.saldo += monto
                        print(f"deposito exitoso. Saldo: Bs {self.saldo:.2f}")
                except ValueError:
                    print("ingrese un monto valido.")
            elif opcion == "3":
                try:
                    monto = float(input("monto a retirar (Bs): "))
                    if monto <= 0:
                        print("el monto debe ser mayor que cero.")
                    elif monto > self.saldo:
                        print("fondos insuficientes.")
                    else:
                        self.saldo -= monto
                        print(f"retiro exitoso. saldo: Bs {self.saldo:.2f}")
                except ValueError:
                    print("ingrese un monto valido.")
            elif opcion == "4":
                print("sesión finalizada.")
                break
            else:
                print("opción no válida.")

if __name__ == "__main__":
    cuentabancaria().ejecutar()
