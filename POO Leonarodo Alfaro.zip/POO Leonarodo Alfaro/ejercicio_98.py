class estadisticasnotas:
    TOTAL_NOTAS = 10
    NOTA_MINIMA_APROBACION = 51  # escala de 0 a 100; ajustar si el docente indica otra.

    def ejecutar(self):
        notas = []
        for i in range(1, self.TOTAL_NOTAS + 1):
            while True:
                try:
                    nota = float(input(f"ingrese la nota {i}/10 (0-100): "))
                    if 0 <= nota <= 100:
                        notas.append(nota)
                        break
                    print("la nota debe estar entre 0 y 100.")
                except ValueError:
                    print("ingrese un numero valido.")
        aprobadas = sum(1 for nota in notas if nota >= self.NOTA_MINIMA_APROBACION)
        reprobadas = self.TOTAL_NOTAS - aprobadas
        print("\n=== ESTADISTICAS ===")
        print(f"aprobadas (>= {self.NOTA_MINIMA_APROBACION}): {aprobadas}")
        print(f"reprobadas (< {self.NOTA_MINIMA_APROBACION}): {reprobadas}")
        print(f"promedio: {sum(notas) / len(notas):.2f}")
        print(f"nota mayor: {max(notas):g}")
        print(f"nota menor: {min(notas):g}")

if __name__ == "__main__":
    estadisticasnotas().ejecutar()
