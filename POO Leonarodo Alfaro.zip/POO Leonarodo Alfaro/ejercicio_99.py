class clasificadoredades:
    def ejecutar(self):
        while True:
            try:
                n = int(input("¿cuantas edades ingresara? "))
                if n > 0:
                    break
                print("la cantidad debe ser mayor que cero.")
            except ValueError:
                print("ingrese un entero valido.")
        ninos = adolescentes = adultos = mayores = 0
        for i in range(1, n + 1):
            while True:
                try:
                    edad = int(input(f"edad {i}/{n}: "))
                    if edad >= 0:
                        break
                    print("la edad no puede ser negativa.")
                except ValueError:
                    print("ingrese una edad entera.")
            if edad <= 11:
                ninos += 1
            elif edad <= 17:
                adolescentes += 1
            elif edad <= 59:
                adultos += 1
            else:
                mayores += 1
        print("\n=== CLASIFICACION ===")
        print(f"niños (0-11): {ninos}")
        print(f"adolescentes (12-17): {adolescentes}")
        print(f"adultos (18-59): {adultos}")
        print(f"adultos mayores (60+): {mayores}")

if __name__ == "__main__":
    clasificadoredades().ejecutar()
